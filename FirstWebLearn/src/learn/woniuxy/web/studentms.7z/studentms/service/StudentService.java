package learn.woniuxy.web.studentms.service;

import java.sql.Connection;
import java.util.List;

import learn.woniuxy.web.studentms.dao.StudentDAO;
import learn.woniuxy.web.studentms.dao.View_AllStudentsDAO;
import learn.woniuxy.web.studentms.po.View_AllStudentsPO;
import learn.woniuxy.web.studentms.util.JDBCUtil;

public class StudentService {
	public List<View_AllStudentsPO> showAllStudents(){
		List<View_AllStudentsPO> stus = null;
		//获取数据连接对象
		JDBCUtil util = new JDBCUtil();
		Connection con = util.getConnection("student");
		stus= new View_AllStudentsDAO().findAllStudents(con);
		util.close(con);
		return stus;
	}

	public String update(int s_id, String s_name, String s_sex, int s_age, String s_phone, int s_no,
			String s_class) {
		String res = "更新失败";
		System.out.println(s_id+s_name+s_sex+s_age+s_phone);
		//Connection con = new JDBCUtil().getConnection("student");
		boolean state = new StudentDAO().updateById(s_id,s_name,s_sex,s_age,s_phone,s_no);
		if(state) {
			res="更新成功";
		}
		return res;
	}
}
