package com.woniuxy.homework;

public enum SexEnum {
	MAN,WOME
}
