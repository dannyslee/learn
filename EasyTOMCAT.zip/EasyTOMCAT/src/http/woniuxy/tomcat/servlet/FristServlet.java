package http.woniuxy.tomcat.servlet;

import http.woniuxy.tomcat.requestandresponse.MyRequest;
import http.woniuxy.tomcat.requestandresponse.MyResponse;

public class FristServlet extends MyHttpServlet {

	@Override
	public void service(MyRequest request, MyResponse response) {
		// TODO Auto-generated method stub
		super.service(request, response);
	}

	@Override
	public void init() {
		// TODO Auto-generated method stub
		super.init();
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		super.destroy();
	}
	
}
